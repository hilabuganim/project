/**
 * 
 */
package unittests;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author hilab
 *
 */
public class CylinderTests {

	/**
	 * Test method for {@link geometries.Tube#getNormal(primitives.Point3D)}.
	 */
	@Test
	public void testGetNormal() {
		fail("Not yet implemented");
	}

}
